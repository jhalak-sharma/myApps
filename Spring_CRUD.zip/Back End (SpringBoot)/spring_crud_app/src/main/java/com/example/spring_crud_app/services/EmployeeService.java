package com.example.spring_crud_app.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import com.example.spring_crud_app.model.Employee;
import com.example.spring_crud_app.repository.EmployeeRepository;

@Service
@Transactional
public class EmployeeService {

    
	@Autowired
    private EmployeeRepository employeeRepository;
   
//	existingEMP
    public Employee addEmployee(Employee employee){
    	Employee existingEMP = employeeRepository.findByempID(employee.getempID());
    	if(existingEMP==null) {
    		employeeRepository.save(employee);
    		System.out.println("Employee added successfully");
    		return existingEMP;
    	}
    	else {
    		System.out.println("Employee ID already exists, create new ID");
    		return employee;
    	}
//    	try {
//    		return employeeRepository.save(employee);
//    		}catch(Exception e) {
//    		}
//		return employeeRepository.save(employee);

	}

	public ArrayList<Employee> getAllEmployees(ArrayList<Employee> employees) {
		return (ArrayList<Employee>) employeeRepository.findAll();
	}
       
	public Employee getEmployeeByempID(@PathVariable int empID) {
		return employeeRepository.findById(empID).orElse(null);
	}
   
	
	Employee existingEMP = null;
	public Employee updateEmployee(Employee employee){

    	existingEMP = (employeeRepository.findByempID(employee.getempID()));
    	
			if(existingEMP!=null){
				employeeRepository.deleteByempID(employee.getempID());;
				employeeRepository.save(employee);
				return employee;
			}
			else{
				return existingEMP;
			}
			
   }
    
    public boolean deleteEmployeeByempID(int empID) {
    	 System.out.println("---------------inside delete block 01----------wher id:"+ empID);
        Employee existingEMP = employeeRepository.findByempID(empID);
        System.out.println("---------------inside delete block----------wher id:"+ existingEMP.getempID());
        employeeRepository.deleteById(empID);
		return true;
    }

}

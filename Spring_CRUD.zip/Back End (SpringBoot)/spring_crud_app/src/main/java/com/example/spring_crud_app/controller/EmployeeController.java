package com.example.spring_crud_app.controller;

import com.example.spring_crud_app.model.Employee;
import com.example.spring_crud_app.services.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

//    Add new employee
    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/addEmployee")
    public Employee addEmployee(@RequestBody Employee employee){
    	    	
    	return employeeService.addEmployee(employee);
    }
    
    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/getAllEmployees")
    public ArrayList<Employee> getAllEmployees(ArrayList<Employee> employees) {
    	System.out.println("get employee method is called ");
    	return employeeService.getAllEmployees(employees);
	}

   /* @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/addAllEmployees")
	public List<Employee> addAllEmployees(@RequestBody List<Employee> employees) {
		return employeeService.addAllEmployees(employees);
	}*/

	// Get Employee by ID
    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/getEmployeeByempID/{empID}")
	public Employee getEmployeeByempID(@PathVariable int empID) {
		return employeeService.getEmployeeByempID(empID);
	}
/*   //Get Employee by name
    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/getEmployeeByName/{name}")
    public Employee getEmployeeByName(@PathVariable String name){
        return employeeService.getEmployeeByName(name);
    }*/
    
    @CrossOrigin(origins = "http://localhost:4200")
    @PutMapping("/updateEmployee")
    public Employee updateEmployee(@RequestBody Employee employee){
    	System.out.println("------------INSIDE UPDATE METHOD IN CONTROLLER------------");
        return employeeService.updateEmployee(employee);
    }
    
//    Delete Employee by id
    @CrossOrigin(origins = "http://localhost:4200")
    @DeleteMapping("/deleteEmployeeByempID/{empID}")
    public void deleteEmployeeByempID(@PathVariable int empID){
    	System.out.println("------------INSIDE DELETE METHOD IN CONTROLLER------------");
    	employeeService.deleteEmployeeByempID(empID); 
    }
}
